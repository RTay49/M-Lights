/*
 * This mbed program was the modify version of the HelloMqtt
 * program show to use in the "week 11 seminar"
 * 
 * The program will connect to doughnut.kent.ac.uk with a 
 * tcp connection and subscribe to the topic 
 * "rt360/assessment5/Mlights/mbed2"
 * upon reciving messages from the Mscan program it will put 
 * the character of the message into a String and upon detecting
 * a "*" character add that string to a vector of strings
 * once a "!" has been detected it ends this process and awaits a 
 * "." character to begin invoke the play() method
 * 
 * the play method will take each element from the vector of strings
 * and add them to a lights vector which is then used by some char 
 * variables through some if statements to see which LED lights should be 
 * turned on and which should be turned off.
 * 
 * due to the mbed being sent two messages (the data/play signal) the
 * mbed should then disconnect from the broker after the light show has
 * been complete.
 * 
 *  notes 
 *  
 *  this mbed uses a previous version of an Ethernet library in order to
 *  work correctly due to a bug in an update.
 * 
 * will print the word finish over and over sometimes during the play() method
 * since this is almost and exact clone as MLights_mbed1 save from subscribing 
 * to a diffrent topic its certainly a very odd behaviour.
 * I did not intend this and have no idea why this happens.
 *
 * 
 */
 
 // change this to 0 to output messages to serial instead of LCD
#define USE_LCD 0

#if USE_LCD
#include "C12832.h"

#if defined(TARGET_UBLOX_C027)
#warning "Compiling for mbed C027"
#include "C027.h"
#elif defined(TARGET_LPC1768)
#warning "Compiling for mbed LPC1768"
#include "LPC1768.h"
#elif defined(TARGET_K64F)
#warning "Compiling for mbed K64F"
#include "K64F.h"
#endif

#define printf lcd.cls();lcd.printf

#endif

#define MQTTCLIENT_QOS2 1

#include "MQTTEthernet.h"
#include "MQTTClient.h"

#include <vector>
#include <string>

DigitalOut r_led(LED_RED);
PwmOut rt_led (D5);
PwmOut g_led (D9);

vector<string> seg;

vector<string>::iterator seg_iterator;
vector<char> lights;



int arrivedcount = 0;
int inputComplete = 0; 
char l1 = '0';
char l2 = '0';

/*
 * The play method is invoked after receiving the activation
 * signal from Mscan via Mqtt. It takes the completed vector of
 * switches and breaks down each string into characters and adds
 * them to the lights vector,
 * 
 * the char variables l1(light 1) & l2 (light 2) take there switches
 * from the lights vector and through some if statements determine 
 * which LED lights to turn on or off.
 */

void play(void)
    {
        
          

    //iterates through the vector of switches
         for (seg_iterator = seg.begin();seg_iterator!=seg.end();++seg_iterator) {
                    
                    lights.clear();
                    string x = *seg_iterator;
                    char l[1024];
                    strncpy(l, x.c_str(), sizeof(l));
                    l[sizeof(l) - 1] = 0;
                  
                    for(char* it = l; *it; ++it) {
                  
                        lights.push_back (*it);
                    }
                        
                        //waits as there are 43 switches per second
                        wait_ms(23);
                            
                            //checks if the song has ended  
                             if(l1 == '!'){
                            
                            printf("finish\n\r");
                                    
                             
                                }
                                 //assaigns the LED lights to be on or off.
                            else{
                             l1 = lights.at(0);
                             l2 = lights.at(1);
                            
                             
                                if (l1 == '1'){
                                    g_led = 0.4;
                                }
                                else if(l1 == '0'){
                                    g_led = 1.0;
                                }
                
                                if (l2 == '1'){
                                    r_led = 0;
                                }
                                else if (l2 == '0'){
                                    r_led = 1;
                                }
                       } 
            
            }
            printf("done\n\r");
        }

/*
 * Modified version of the original HelloMqtt message Arrived method
 * now this method will both display the message and pass it characters
 * to from strings. Every "*" character will cause the strings to be added
 * to the seg vector of switches and resets the string
 * 
 *  If a "!" character is detected the song is then complete and the 
 *  program will wait for the activation signal since the program waits
 *  for two messages until it disconnects from the Mqtt broker
 *  
 *  if a message that contains a "." character is sent the program will
 *  invoke the play() method.
 *
 */

void messageArrived(MQTT::MessageData& md)
{
    MQTT::Message &message = md.message;
    printf("Message arrived: qos %d, retained %d, dup %d, packetid %d\n\r", message.qos, message.retained, message.dup, message.id);
    printf("Payload %.*s\n", message.payloadlen, (char*)message.payload);
    
    //puts the message into a Char array
    char* input;
    input =  (char*)message.payload;
    string sw;
    for(char* it = input; *it; ++it) {
    char x = *it;
   
   //checks if activation message
    if(x == '.'){
        play ();
        }
    
    //adds each chacter to a string    
        sw = sw + x;
   
   
    // tell the program this segment is complete and adds 
    // it to the seg vector and resets the string
    if(x == '*'){
         seg.push_back (sw);
         sw = "";
        }
    
     //tells us the song has been processed
    if(sw == "!"){
        inputComplete = 1;
        printf("input Complete");
        printf("\n\r");
        
        }
    }
    
    ++arrivedcount;
    
}


int main(int argc, char* argv[])



{   
     g_led = 1.0;
    r_led = 1;
    rt_led = 1.0;
    
    
    
    MQTTEthernet ipstack = MQTTEthernet();
    float version = 0.5;
    char* topic = "rt360/assessment5/Mlights/mbed2";
    
    printf("HelloMQTT: version is %f\n\r", version);
              
    MQTT::Client<MQTTEthernet, Countdown> client = MQTT::Client<MQTTEthernet, Countdown>(ipstack);
    
    char* hostname = "doughnut.kent.ac.uk";
    int port = 1883;
    printf("mbed2 Connecting to %s:%d\n\r", hostname, port);
    int rc = ipstack.connect(hostname, port);
    if (rc != 0)
        printf("rc from TCP connect is %d\n\r", rc);
    MQTTPacket_connectData data = MQTTPacket_connectData_initializer;       
    data.MQTTVersion = 3;
    data.clientID.cstring = "Mbed_twoA";
    //data.username.cstring = "";
    //data.password.cstring = "";
   
   printf("connected\n\r");
   
    if ((rc = client.connect(data)) != 0)
        printf("rc from MQTT connect is %d\n\r", rc);
    
    if ((rc = client.subscribe(topic, MQTT::QOS2, messageArrived)) != 0)
        printf("rc from MQTT subscribe is %d\n\r", rc);


        
     while (arrivedcount < 2)
        client.yield(100);
            
    if ((rc = client.unsubscribe(topic)) != 0)
        printf("rc from unsubscribe was %d\n\r", rc);
    
    if ((rc = client.disconnect()) != 0)
        printf("rc from disconnect was %d\n\r", rc);
    
    ipstack.disconnect();
    printf("disconnected\n\r");
    printf("Version %.2f: finish %d msgs\n\r", version, arrivedcount);
    
    return 0;
}
